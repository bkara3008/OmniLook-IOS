﻿/*
 // Decompiled with JetBrains decompiler
   // Type: OmniWS.DataTransfer
   // Assembly: OmniWS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
   // MVID: BFBC23BE-71E9-4566-B731-976DCF80DB05
   // Assembly location: \\Mac\Home\Downloads\OmniWS\OmniWS\bin\OmniWS.dll
   
   using DataAccessLayer;
   using System;
   using System.Data.SqlClient;
   using System.Web.Security;
   using System.Web.UI;
   using System.Web.UI.HtmlControls;
   
   #nullable disable
   namespace OmniWS
   {
     public class DataTransfer : Page
     {
       protected HtmlForm form1;
   
       protected void Page_Load(object sender, EventArgs e)
       {
         string header = this.Request.Headers["method"];
         if (header == null)
           return;
         if (header.Equals("FIRMA_LISTESI"))
           this.FIRMA_LISTESI();
         if (header.Equals("FIRMA_GRUP_LISTESI"))
           this.FIRMA_GRUBU();
         if (header.Equals("KULLANICI_KONTROL"))
           this.KULLANICI_KONTROL();
         if (header.Equals("OMNI_RPT_MBL_KASA_SATIS"))
           this.OMNI_RPT_MBL_KASA_SATIS();
         else if (header.Equals("OMNI_RPT_MBL_COK_SATILAN_URUNLER"))
           this.OMNI_RPT_MBL_COK_SATILAN_URUNLER();
         else if (header.Equals("OMNI_RPT_MBL_SIPARIS_TIPI"))
           this.OMNI_RPT_MBL_SIPARIS_TIPI();
         else if (header.Equals("OMNI_RPT_MBL_PERSONEL"))
           this.OMNI_RPT_MBL_PERSONEL();
         else if (header.Equals("OMNI_RPT_MBL_ACIK_CEKLER"))
           this.OMNI_RPT_MBL_ACIK_CEKLER();
         else if (header.Equals("OMNI_RPT_MBL_ANA_GRUP_2_SATIS"))
           this.OMNI_RPT_MBL_ANA_GRUP_2_SATIS();
         else if (header.Equals("OMNI_RPT_MBL_INDIRIM_DETAY"))
           this.OMNI_RPT_MBL_INDIRIM_DETAY();
         else if (header.Equals("OMNI_RPT_MBL_ODENMEZ_IKRAM"))
           this.OMNI_RPT_MBL_ODENMEZ_IKRAM();
         else if (header.Equals("OMNI_RPT_MBL_GELIR_ACIK_CEKLER"))
           this.OMNI_RPT_MBL_GELIR_ACIK_CEKLER();
         else if (header.Equals("OMNI_RPT_MBL_KASA_SATIS_ODEME"))
           this.OMNI_RPT_MBL_KASA_SATIS_ODEME();
         this.Response.End();
       }
   
       private void KULLANICI_KONTROL()
       {
         string str = FormsAuthentication.HashPasswordForStoringInConfigFile(this.Request.Headers["sifre"], "MD5");
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sSQL = "SELECT KULLANICI_ID FROM ARG_CRM_KULLANICI WHERE KULLANICI_ADI=@kullaniciadi AND SIFRE=@sifre";
           dbFactory.SQLParams.Add(new SqlParameter("kullaniciadi", (object) this.Request.Headers["kullaniciadi"]));
           dbFactory.SQLParams.Add(new SqlParameter("sifre", (object) str));
           this.Response.Write("[" + dbFactory.ReturnToList() + "]");
         }
       }
   
       private void FIRMA_GRUBU()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sSQL = "SELECT FIRMA_GRUBU_ID, GRUP_ADI FROM ARG_CRM_FIRMA_GRUBU ORDER BY GRUP_ADI ";
           this.Response.Write("[" + dbFactory.ReturnToList() + "]");
         }
       }
   
       private void FIRMA_LISTESI()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sSQL = "SELECT F.FIRMA_ID, F.FIRMA_ADI FROM ARG_CRM_FIRMA_GENEL AS F ";
           dbFactory.sSQL += " INNER JOIN ARG_CRM_FIRMA_KULLANICI AS FK ON F.FIRMA_ID = FK.FIRMA_ID ";
           dbFactory.sSQL += " WHERE F.FIRMA_GRUBU_ID=@firmagrubuid AND FIRMA_TURU_ID=16 AND FK.KULLANICI_ID=@kullaniciid ";
           dbFactory.sSQL += " ORDER BY F.FIRMA_ADI ";
           dbFactory.SQLParams.Add(new SqlParameter("kullaniciid", (object) this.Request.Headers["kullaniciid"]));
           dbFactory.SQLParams.Add(new SqlParameter("firmagrubuid", (object) this.Request.Headers["firmagrubuid"]));
           this.Response.Write("[" + dbFactory.ReturnToList() + "]");
         }
       }
   
       private void OMNI_RPT_MBL_KASA_SATIS()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sProcName = nameof (OMNI_RPT_MBL_KASA_SATIS);
           dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", (object) this.Request.Headers["kullaniciid"]));
           dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", (object) this.Request.Headers["firmaid"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH1", (object) this.Request.Headers["tarih1"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH2", (object) this.Request.Headers["tarih2"]));
           this.Response.Write("[" + dbFactory.ReturnToListProc() + "]");
         }
       }
   
       private void OMNI_RPT_MBL_COK_SATILAN_URUNLER()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sProcName = nameof (OMNI_RPT_MBL_COK_SATILAN_URUNLER);
           dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", (object) this.Request.Headers["kullaniciid"]));
           dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", (object) this.Request.Headers["firmaid"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH1", (object) this.Request.Headers["tarih1"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH2", (object) this.Request.Headers["tarih2"]));
           dbFactory.SQLParams.Add(new SqlParameter("COUNT", (object) "100"));
           this.Response.Write("[" + dbFactory.ReturnToListProc() + "]");
         }
       }
   
       private void OMNI_RPT_MBL_SIPARIS_TIPI()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sProcName = nameof (OMNI_RPT_MBL_SIPARIS_TIPI);
           dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", (object) this.Request.Headers["kullaniciid"]));
           dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", (object) this.Request.Headers["firmaid"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH1", (object) this.Request.Headers["tarih1"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH2", (object) this.Request.Headers["tarih2"]));
           this.Response.Write("[" + dbFactory.ReturnToListProc() + "]");
         }
       }
   
       private void OMNI_RPT_MBL_PERSONEL()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sProcName = nameof (OMNI_RPT_MBL_PERSONEL);
           dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", (object) this.Request.Headers["kullaniciid"]));
           dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", (object) this.Request.Headers["firmaid"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH1", (object) this.Request.Headers["tarih1"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH2", (object) this.Request.Headers["tarih2"]));
           this.Response.Write("[" + dbFactory.ReturnToListProc() + "]");
         }
       }
   
       private void OMNI_RPT_MBL_ACIK_CEKLER()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sProcName = nameof (OMNI_RPT_MBL_ACIK_CEKLER);
           dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", (object) this.Request.Headers["kullaniciid"]));
           dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", (object) this.Request.Headers["firmaid"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH1", (object) this.Request.Headers["tarih1"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH2", (object) this.Request.Headers["tarih2"]));
           this.Response.Write("[" + dbFactory.ReturnToListProc() + "]");
         }
       }
   
       private void OMNI_RPT_MBL_ANA_GRUP_2_SATIS()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sProcName = nameof (OMNI_RPT_MBL_ANA_GRUP_2_SATIS);
           dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", (object) this.Request.Headers["kullaniciid"]));
           dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", (object) this.Request.Headers["firmaid"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH1", (object) this.Request.Headers["tarih1"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH2", (object) this.Request.Headers["tarih2"]));
           this.Response.Write("[" + dbFactory.ReturnToListProc() + "]");
         }
       }
   
       private void OMNI_RPT_MBL_INDIRIM_DETAY()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sProcName = nameof (OMNI_RPT_MBL_INDIRIM_DETAY);
           dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", (object) this.Request.Headers["kullaniciid"]));
           dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", (object) this.Request.Headers["firmaid"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH1", (object) this.Request.Headers["tarih1"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH2", (object) this.Request.Headers["tarih2"]));
           this.Response.Write("[" + dbFactory.ReturnToListProc() + "]");
         }
       }
   
       private void OMNI_RPT_MBL_ODENMEZ_IKRAM()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sProcName = nameof (OMNI_RPT_MBL_ODENMEZ_IKRAM);
           dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", (object) this.Request.Headers["kullaniciid"]));
           dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", (object) this.Request.Headers["firmaid"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH1", (object) this.Request.Headers["tarih1"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH2", (object) this.Request.Headers["tarih2"]));
           this.Response.Write("[" + dbFactory.ReturnToListProc() + "]");
         }
       }
   
       private void OMNI_RPT_MBL_GELIR_ACIK_CEKLER()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sProcName = nameof (OMNI_RPT_MBL_GELIR_ACIK_CEKLER);
           dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", (object) this.Request.Headers["kullaniciid"]));
           dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", (object) this.Request.Headers["firmaid"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH1", (object) this.Request.Headers["tarih1"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH2", (object) this.Request.Headers["tarih2"]));
           this.Response.Write("[" + dbFactory.ReturnToListProc() + "]");
         }
       }
   
       private void OMNI_RPT_MBL_KASA_SATIS_ODEME()
       {
         using (DBFactory dbFactory = new DBFactory())
         {
           dbFactory.sProcName = nameof (OMNI_RPT_MBL_KASA_SATIS_ODEME);
           dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", (object) this.Request.Headers["kullaniciid"]));
           dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", (object) this.Request.Headers["firmaid"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH1", (object) this.Request.Headers["tarih1"]));
           dbFactory.SQLParams.Add(new SqlParameter("TARIH2", (object) this.Request.Headers["tarih2"]));
           this.Response.Write("[" + dbFactory.ReturnToListProc() + "]");
         }
       }
     }
   }
   
 */