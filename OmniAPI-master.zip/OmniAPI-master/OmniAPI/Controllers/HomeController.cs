﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace OmniAPI.Controllers
{
    public class HomeController : Controller
    {
        private static readonly string key = "1234567890123456";
        private static readonly string iv = "abcdefghijklmnop";


        public string KULLANICI_KONTROL(string kullaniciAdi, string sifre)
        {
            //var decodeKullaniciAdi = Decrypt(kullaniciAdi);
            //var decodeSifre = Decrypt(sifre);

            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sSQL = "SELECT KULLANICI_ID FROM ARG_CRM_KULLANICI WHERE KULLANICI_ADI=@kullaniciadi AND SIFRE=@sifre";
                dbFactory.SQLParams.Add(new SqlParameter("kullaniciadi", kullaniciAdi));
                dbFactory.SQLParams.Add(new SqlParameter("sifre", sifre));
                return "[" + dbFactory.ReturnToList() + "]";
            }
        }

        public string FIRMA_GRUBU()
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sSQL = "SELECT FIRMA_GRUBU_ID, GRUP_ADI FROM ARG_CRM_FIRMA_GRUBU WHERE GRUP_KODU IS NULL ORDER BY GRUP_ADI ";
                return "[" + dbFactory.ReturnToList() + "]";
            }
        }

        public string FIRMA_LISTESI(string kullaniciid, string firmagrubuid)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sSQL = " SELECT F.FIRMA_ID, F.FIRMA_ADI FROM ARG_CRM_FIRMA_GENEL AS F ";
                dbFactory.sSQL += " INNER JOIN ARG_CRM_FIRMA_KULLANICI AS FK ON F.FIRMA_ID = FK.FIRMA_ID ";
                dbFactory.sSQL += " WHERE F.FIRMA_GRUBU_ID=@firmagrubuid AND FIRMA_TURU_ID=16 AND F.MUSTERI_SINIFI_ID IS NULL AND FK.KULLANICI_ID=@kullaniciid ";
                dbFactory.sSQL += " ORDER BY F.FIRMA_ADI ";
                dbFactory.SQLParams.Add(new SqlParameter("kullaniciid", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("firmagrubuid", firmagrubuid));
                return "[" + dbFactory.ReturnToList() + "]";
            }
        }

        public string OMNI_RPT_MBL_KASA_SATIS(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_KASA_SATIS);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        public string OMNI_RPT_MBL_COK_SATILAN_URUNLER(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_COK_SATILAN_URUNLER);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("COUNT", (object)"100"));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        public string OMNI_RPT_MBL_SIPARIS_TIPI(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_SIPARIS_TIPI);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        public string OMNI_RPT_MBL_PERSONEL(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_PERSONEL);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        public string OMNI_RPT_MBL_ACIK_CEKLER(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_ACIK_CEKLER);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        public string OMNI_RPT_MBL_ANA_GRUP_2_SATIS(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_ANA_GRUP_2_SATIS);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        public string OMNI_RPT_MBL_INDIRIM_DETAY(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_INDIRIM_DETAY);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        public string OMNI_RPT_MBL_ODENMEZ_IKRAM(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_ODENMEZ_IKRAM);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        public string OMNI_RPT_MBL_GELIR_ACIK_CEKLER(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_GELIR_ACIK_CEKLER);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        public string OMNI_RPT_MBL_KASA_SATIS_ODEME(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_KASA_SATIS_ODEME);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        public string OMNI_RPT_MBL_SATIS_VE_KARLILIK(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_SATIS_VE_KARLILIK);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        public string OMNI_RPT_MBL_DASHBOARD_DATA(string kullaniciid, string firmaid, string tarih1, string tarih2, string curr)
        {
            using (DBFactory dbFactory = new DBFactory())
            {
                dbFactory.sProcName = nameof(OMNI_RPT_MBL_DASHBOARD_DATA);
                dbFactory.SQLParams.Add(new SqlParameter("KULLANICI_ID", kullaniciid));
                dbFactory.SQLParams.Add(new SqlParameter("FIRMA_IDs", firmaid));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH1", tarih1));
                dbFactory.SQLParams.Add(new SqlParameter("TARIH2", tarih2));
                dbFactory.SQLParams.Add(new SqlParameter("CURR", curr));
                return "[" + dbFactory.ReturnToListProc() + "]";
            }
        }

        private static string Decrypt(string cipherText)
        {
            byte[] buffer = Convert.FromBase64String(cipherText);

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = Encoding.UTF8.GetBytes(iv);
                aes.Padding = PaddingMode.PKCS7;

                using (ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
                {
                    byte[] result = decryptor.TransformFinalBlock(buffer, 0, buffer.Length);
                    return Encoding.UTF8.GetString(result);
                }
            }
        }

    }
}
